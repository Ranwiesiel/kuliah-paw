<?php
$height = array("Andy"=>"176", "Barry"=>"165", "Charlie"=>"170");

foreach($height as $x => $x_value) {
	echo "Key=" . $x . ", Value=" . $x_value;
	echo "<br>";
}

// No 9
$data_baru = array(["Ado" => "171"], ["Kelvin" => "173"], ["Noah" => "169"], ["Oliver" => "175"], ["Liam" => "177"]);
foreach($data_baru as $key => $value){
	array_push($height, [$key => $value]);
}

// No 10
$weight = array("Andy" => "60", "Charlie" => "70", "Ado" => "58");
foreach($weight as $x => $x_value) {
	echo "Key=" . $x . ", Value=" . $x_value;
	echo "<br>";
}