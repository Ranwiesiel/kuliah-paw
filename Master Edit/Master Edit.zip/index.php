<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
	<title>Homepage</title>

	<style>
	body {
  		background-image: url('bg1.jpg');
  		background-repeat: no-repeat;
  		background-attachment: fixed;  
  		background-size: cover;
	}

	.tengah {
		margin-left: 47%;
		margin-top:20%;
	}
	</style>
</head>
<body>
	<div class="tengah" >
	<a class="btn btn-secondary" href="menu.php" role="button">Menu</a>
	</div>
</body>
</html>